"""IGMP report simulator."""

import argparse
from ipaddress import IPv4Address, ip_address

from scapy.all import send
from scapy.contrib.igmpv3 import IGMPv3, IGMPv3gr, IGMPv3mr
from scapy.layers.inet import IP


def send_igmpv3_membership_report(
    multicast_group_record: list[str], interface: str, count: int = 1
) -> None:
    """Send an IGMPv3 report with desired multicast record.

    Multicast source and group must be IPv4 addresses.

    Multicast Group record format:

      - <mcast_src>;<mcast_grp>;<record type>
      - <mcast_src>,...<mcast_src>;<mcast_grp>;<record type>
      - ;<mcast_grp>;<record type>

    :param multicast_group_record: Multicast group record with IPv4 addresses
    :type multicast_group_record: list[str]
    :param interface: Interface to send the packet from
    :type interface: str
    :param count: Count of packets to send in a 1s interval, defaults to 1
    :type count: int, optional
    :raises TypeError: If mcast type is invalid. i.e. Not between 1 to 6
    :raises TypeError: If mcast group is either IPv6/non-multicast range addr
    :raises TypeError: If mcast source is either IPv6/multicast range addr
    :raises RuntimeError: If unable to send any packets
    """
    # Create a base Membership report class
    report = IGMPv3mr()

    for record in multicast_group_record:
        sources, mcast, rtype = record.split(";")

        # Create group records
        group_record = IGMPv3gr()

        if not 1 <= int(rtype) <= 6:
            raise TypeError(f"{rtype} is not a valid multicast record type")
        group_record.rtype = int(rtype)

        # Modify the multicast address
        if not (
            ip_address(mcast).is_multicast
            and isinstance(ip_address(mcast), IPv4Address)
        ):
            raise TypeError(f"{mcast} is not an IPv4 multicast address")
        group_record.maddr = mcast

        if sources.strip():
            for source in sources.split(","):
                addr = ip_address(source)
                if not (not addr.is_multicast and isinstance(addr, IPv4Address)):
                    raise TypeError(
                        f"{source} is not an IPv4 non-multicast address in sources"
                    )

            # Add the multicast sources
            group_record.srcaddrs = sources.split(",")

        # Add the record to the membership report
        report.records.append(group_record)

    packet = IP() / IGMPv3() / report

    try:
        out = send(packet, loop=1, count=count, iface=interface, return_packets=True)
        out.show()
    except Exception as exc:
        raise RuntimeError("Could not send the IGMPv3 packet") from exc


def main() -> None:
    """To parse the CLI and run the main function.

    :raises ValueError: If IGMPv2 is opted as the version.
    """
    cli_description = """
    Multicast Record Syntax:
    [<mcast src addr>,..];<mcast group addr>;<record type>
    """

    parser = argparse.ArgumentParser(
        description="Sends a IGMPv2/v3 packet using the python scapy library.",
        epilog=cli_description,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "-i",
        "--iface",
        type=str,
        default="lo",
        help="Target interface to send the multicast packet on.",
    )
    parser.add_argument(
        "-c",
        "--count",
        type=int,
        default="1",
        help="Number of packets to be sent in a 1s interval",
    )
    parser.add_argument(
        "--igmp_version",
        type=int,
        default="3",
        help="Default IGMP version to be used",
    )
    parser.add_argument(
        "-mr",
        "--multicast_record",
        action="append",
        default=[],
        required=True,
        help="Number of packets to be sent between 1s intervals",
    )
    args = parser.parse_args()

    # Need to add support for IGMPv2 later.
    if args.igmp_version == 3:
        send_igmpv3_membership_report(
            multicast_group_record=args.multicast_record,
            interface=args.iface,
            count=args.count,
        )
    else:
        raise ValueError("Version IGMPv3 supported only!!")


if __name__ == "__main__":
    main()
