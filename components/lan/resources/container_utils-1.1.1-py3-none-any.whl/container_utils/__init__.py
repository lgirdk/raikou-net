"""Utilities for Test Infrastructure containers.

The containers are used by the Boardfarm Project at Liberty Global.
The utilities shall include python packaged programs that are loaded
in LAN/WAN/provisioning containers.
"""

__version__ = "1.1.1"
